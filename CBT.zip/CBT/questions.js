var questions = [
    {
        'id': 1, 'question': 'What is a noun?', 'answers':[
            {
                'id': 1, 'answer': 'a noun is the name of place, animal or things', 'correct': true
            },
            {
                'id': 2, 'answer': 'a noun is the name of adjectives, animal or describe', 'correct': false
            },
            {
                'id': 3, 'answer': 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', 'correct': false
            },
        ]
    },
    {
        'id': 2, 'question': 'I love my _____?', 'answers':[
            {
                'id': 1, 'answer': 'Lorem ipsum dolor sit amet consectetur adipisi', 'correct': false
            },
            {
                'id': 2, 'answer': 'myself', 'correct': true
            },
            {
                'id': 3, 'answer': 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', 'correct': false
            },
        ]
    },
    {
        'id': 3, 'question': 'Bola _____ to school everyday', 'answers':[
            {
                'id': 1, 'answer': 'went', 'correct': false
            },
            {
                'id': 2, 'answer': 'goes', 'correct': true
            },
            {
                'id': 3, 'answer': 'came', 'correct': false
            },
        ]
    },
    {
        'id': 4, 'question': 'She is _____ tomorrow', 'answers':[
            {
                'id': 1, 'answer': 'coming', 'correct': true
            },
            {
                'id': 2, 'answer': 'goes', 'correct': false
            },
            {
                'id': 3, 'answer': 'came', 'correct': false
            },
            {
                'id': 4, 'answer': 'went', 'correct': false
            },
        ]
    },
    {
        'id': 5, 'question': 'Are ______ okay?', 'answers':[
            {
                'id': 1, 'answer': 'I', 'correct': false
            },
            {
                'id': 2, 'answer': 'them', 'correct': false
            },
            {
                'id': 3, 'answer': 'me', 'correct': false
            },
            {
                'id': 4, 'answer': 'you', 'correct': true
            },
        ]
    }
]