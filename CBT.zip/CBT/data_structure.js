const exams= [
    {
        id, 
        title, 
        descripton,
        duration,
        status
    }
]

const questions = [
    {
        id, 
        question,
        exam_id,
        subject_id, 
        answers:[
            {id, answer, correct}
        ],
    }
]

const subjects = [
    {
        id,
        title
    }
]

const classes = [
    {
        id,
        title
    }
]

const results = [
    {
        id,
        student_id,
        exam_id,
        subject_id,
        class_id,
        year,
        score,
    }
]

const teachers = []

const students = []

const users = []