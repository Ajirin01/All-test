<html>
<head>
<title>Card V</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (Card V.svg - Slices: 03, 06, 09, 13, 16, 21, 23, 25, 28, 32) -->
<table style="background-image: url(template-images/card-05/images/Card-V-BG.jpg); background-position: center; background-size: cover; background-repeat: no-repeat;" id="Table_01" width="551" height="421" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="550" height="10" colspan="18">
			<img src="template-images/card-05/images/spacer.gif" width="550" height="10" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td width="385" height="65" colspan="12">
			<img src="template-images/card-05/images/spacer.gif" width="385" height="65" alt=""></td>
		<td colspan="2" rowspan="3" align="left" valign="top">
			<div class="logo">
				<img id="logo-image" src="<?=$logo?>" width="146" height="141" alt="">
			</div>
		</td>
		<td width="19" height="264" colspan="4" rowspan="6">
			<img src="template-images/card-05/images/spacer.gif" width="19" height="264" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="65" alt=""></td>
	</tr>
	<tr>
		<td width="25" height="317" colspan="2" rowspan="12">
			<img src="template-images/card-05/images/spacer.gif" width="25" height="317" alt=""></td>
		<td align="left" valign="top">
			<div style="text-transform: uppercase; font-weight:600; margin-left: 20px; font-size: 1rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="position"><?=$position?></span>
			</div>
		</td>
		<td width="130" height="76" colspan="9" rowspan="2">
			<img src="template-images/card-05/images/spacer.gif" width="130" height="76" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="50" alt=""></td>
	</tr>
	<tr>
		<td width="230" height="26">
			<img src="template-images/card-05/images/spacer.gif" width="230" height="26" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="26" alt=""></td>
	</tr>
	<tr>
		<td colspan="11" align="left" valign="top">
			<div style="text-transform: uppercase; font-weight:800; margin-left: 20px; font-size: 4rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="card-owner-name"><?=$name?></span>
			</div>
		</td>
		<td width="38" height="123" rowspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="38" height="123" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="95" alt=""></td>
	</tr>
	<tr>
		<td width="468" height="18" colspan="11">
			<img src="template-images/card-05/images/spacer.gif" width="468" height="18" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="18" alt=""></td>
	</tr>
	<tr>
		<td width="274" height="42" colspan="4" rowspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="274" height="42" alt=""></td>
		<td rowspan="2" align="left" valign="top">
			<img src="template-images/card-05/images/Card-V_13.jpg" width="44" height="41" alt=""></td>
		<td width="150" height="10" colspan="6">
			<img src="template-images/card-05/images/spacer.gif" width="150" height="10" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td width="6" height="42" colspan="4" rowspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="6" height="42" alt=""></td>
		<td colspan="6" align="left" valign="top">
			<div style="margin-top: 3px;font-weight: 400; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="email"><?=$email?></span>
			</div>
		</td>
		<td width="7" height="146" rowspan="10">
			<img src="template-images/card-05/images/spacer.gif" width="7" height="146" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="31" alt=""></td>
	</tr>
	<tr>
		<td width="44" height="1">
			<img src="template-images/card-05/images/spacer.gif" width="44" height="1" alt=""></td>
		<td width="194" height="11" colspan="6" rowspan="2">
			<img src="template-images/card-05/images/spacer.gif" width="194" height="11" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="1" alt=""></td>
	</tr>
	<tr>
		<td width="273" height="86" colspan="3" rowspan="5">
			<img src="template-images/card-05/images/spacer.gif" width="273" height="86" alt=""></td>
		<td colspan="2" rowspan="2" align="left" valign="top">
			<img src="template-images/card-05/images/Card-V_21.jpg" width="45" height="36" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td width="5" height="26" colspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="5" height="26" alt=""></td>
		<td colspan="5" align="left" valign="top">
			<div style="font-weight: 400; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="phone"><?=$phone?></span>
			</div>
		</td>
		<td width="8" height="34" colspan="2" rowspan="2">
			<img src="template-images/card-05/images/spacer.gif" width="8" height="34" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="26" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" rowspan="2" align="left" valign="top">
			<img src="template-images/card-05/images/Card-V_25.jpg" width="46" height="39" alt=""></td>
		<td width="191" height="8" colspan="7">
			<img src="template-images/card-05/images/spacer.gif" width="191" height="8" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td width="3" height="70" rowspan="5">
			<img src="template-images/card-05/images/spacer.gif" width="3" height="70" alt=""></td>
		<td colspan="7" rowspan="3" align="left" valign="top">
			<div style="font-weight: 400; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="address"><?=$address?></span>
			</div>
		</td>
		<td width="2" height="70" rowspan="5">
			<img src="template-images/card-05/images/spacer.gif" width="2" height="70" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="31" alt=""></td>
	</tr>
	<tr>
		<td width="46" height="39" colspan="3" rowspan="4">
			<img src="template-images/card-05/images/spacer.gif" width="46" height="39" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="11" alt=""></td>
	</tr>
	<tr>
		<td width="7" height="28" rowspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="7" height="28" alt=""></td>
		<td colspan="3" rowspan="2" align="left" valign="top">
			<div style="font-style: italic; font-weight: 500; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="testimony"><?=$testimony?></span>
			</div>
		</td>
		<td width="21" height="28" rowspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="21" height="28" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td width="194" height="20" colspan="7" rowspan="2">
			<img src="template-images/card-05/images/spacer.gif" width="194" height="20" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="18" alt=""></td>
	</tr>
	<tr>
		<td width="270" height="2" colspan="3">
			<img src="template-images/card-05/images/spacer.gif" width="270" height="2" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="7" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="18" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="230" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="22" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="21" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="44" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="3" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="36" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="108" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="38" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="6" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="2" height="1" alt=""></td>
		<td>
			<img src="template-images/card-05/images/spacer.gif" width="7" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>