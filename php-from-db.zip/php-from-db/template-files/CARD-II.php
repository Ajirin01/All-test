<HTML>
<HEAD>
<TITLE>Card II (SVG)</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<!-- ImageReady Slices (Card II (SVG).svg - Slices: 00, 03, 06, 09, 15, 18, 22, 25, 30, 32, 35) -->
<TABLE style="color: white; background-image: url('template-images/card-02/images/Card-II-BG.jpg'); background-repeat: no-repeat; background-position: center; background-size: contain" ID="Table_01" WIDTH=551 HEIGHT=421 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD WIDTH=550 HEIGHT=10 COLSPAN=15>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=550 HEIGHT=10 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=10 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=22 HEIGHT=410 ROWSPAN=18>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=22 HEIGHT=410 ALT=""></TD>
		<TD ROWSPAN=10 ALIGN=left VALIGN=top>
			<IMG id="logo-image" SRC="<?=$logo?>" WIDTH=173 HEIGHT=169 ALT="">
			</TD>
		<TD WIDTH=355 HEIGHT=6 COLSPAN=13>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=355 HEIGHT=6 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=6 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=94 HEIGHT=180 COLSPAN=2 ROWSPAN=12>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=94 HEIGHT=180 ALT=""></TD>
		<TD COLSPAN=4 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_06.jpg" WIDTH=59 HEIGHT=10 ALT=""></TD>
		<TD WIDTH=202 HEIGHT=10 COLSPAN=7>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=202 HEIGHT=10 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=10 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 ROWSPAN=2 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_08.jpg" WIDTH=58 HEIGHT=38 ALT=""></TD>
		<TD COLSPAN=7 ALIGN=left VALIGN=top>
			<div style="margin-top: 5px">
				<span id="phone" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><?=$phone?></span>
			</div>
		</TD>
		<TD WIDTH=9 HEIGHT=394 ROWSPAN=16>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=9 HEIGHT=394 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=32 ALT=""></TD>
	</TR>
	<TR>
		<TD ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_11.jpg" WIDTH=1 HEIGHT=6 ALT=""></TD>
		<TD WIDTH=193 HEIGHT=10 COLSPAN=6 ROWSPAN=2>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=193 HEIGHT=10 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=6 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=59 HEIGHT=4 COLSPAN=4>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=59 HEIGHT=4 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=4 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=2 HEIGHT=62 COLSPAN=2 ROWSPAN=3>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=2 HEIGHT=62 ALT=""></TD>
		<TD COLSPAN=4 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_15.jpg" WIDTH=60 HEIGHT=18 ALT=""></TD>
		<TD WIDTH=190 HEIGHT=18 COLSPAN=4>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=190 HEIGHT=18 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=18 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 ROWSPAN=2 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_17.jpg" WIDTH=59 HEIGHT=44 ALT=""></TD>
		<TD COLSPAN=5 ALIGN=left VALIGN=top>
			<div style="margin-top: 5px;">
				<span id="email" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><?=$email?></span>
			</div>
		</TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=32 ALT=""></TD>
	</TR>
	<TR>
		<TD ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_19.jpg" WIDTH=1 HEIGHT=12 ALT=""></TD>
		<TD WIDTH=190 HEIGHT=12 COLSPAN=4>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=190 HEIGHT=12 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=12 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=1 HEIGHT=66 ROWSPAN=5>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=66 ALT=""></TD>
		<TD COLSPAN=7 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_22.jpg" WIDTH=63 HEIGHT=11 ALT=""></TD>
		<TD WIDTH=188 HEIGHT=11 COLSPAN=2>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=188 HEIGHT=11 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=11 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=6 ROWSPAN=3 ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_24.jpg" WIDTH=62 HEIGHT=51 ALT=""></TD>
		<TD COLSPAN=3 ROWSPAN=2 ALIGN=left VALIGN=top>
			<div style="margin-top: 5px;">
				<span id="address" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><?=$address?></span>
			</div>
		</TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=38 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=173 HEIGHT=17 ROWSPAN=3>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=173 HEIGHT=17 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=9 ALT=""></TD>
	</TR>
	<TR>
		<TD ALIGN=left VALIGN=top>
			<IMG SRC="template-images/card-02/images/Card-2_27.jpg" WIDTH=1 HEIGHT=4 ALT=""></TD>
		<TD WIDTH=188 HEIGHT=147 COLSPAN=2 ROWSPAN=5>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=188 HEIGHT=147 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=4 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=63 HEIGHT=4 COLSPAN=7>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=63 HEIGHT=4 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=4 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=9 ALIGN=left VALIGN=top>
			<div>
				<span id="card-owner-name" style="font-family: Brush Script Std Medium; font-size: 2.5rem; "><?=$name?></span>
			</div>
		</TD>
		<TD WIDTH=2 HEIGHT=139 COLSPAN=2 ROWSPAN=3>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=2 HEIGHT=139 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=75 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=2 ALIGN=left VALIGN=top>
			<div>
				<span id="position" style="font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif"><?=$position;?></span>
			</div>
		</TD>
		<TD WIDTH=91 HEIGHT=64 COLSPAN=7 ROWSPAN=2>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=91 HEIGHT=64 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=30 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=238 HEIGHT=119 COLSPAN=2 ROWSPAN=3>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=238 HEIGHT=119 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=34 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=10 ALIGN=left VALIGN=top>
			<div>
				<span id="testimony" style="color: #2DCC70; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif"><?=$testimony?></span>
			</div>
		</TD>
		<TD WIDTH=18 HEIGHT=85 ROWSPAN=2>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=18 HEIGHT=85 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=56 ALT=""></TD>
	</TR>
	<TR>
		<TD WIDTH=263 HEIGHT=29 COLSPAN=10>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=263 HEIGHT=29 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=29 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=22 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=173 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=65 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=29 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=56 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=2 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=1 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=170 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=18 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="template-images/card-02/images/spacer.gif" WIDTH=9 HEIGHT=1 ALT=""></TD>
		<TD></TD>
	</TR>
</TABLE>
<!-- End ImageReady Slices -->
</BODY>
</HTML>