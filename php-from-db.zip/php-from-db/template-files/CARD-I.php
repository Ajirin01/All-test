<html>
<head>
<title>CARD DESIGN I</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (CARD DESIGN I.svg) -->
<table style="background-image: url(template-images/card-01/images/CARD-DESIGN-I-BG.jpg); background-repeat: no-repeat; background-position: center; background-size: cover" id="Table_01" width="551" height="421" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="18"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="31" alt="">
		</td>
	</tr>
	<tr>
		<td rowspan="15"></td>
		<td colspan="5" rowspan="2" align="left" valign="top">
			<div id="position"><?=$position;?></div>
		</td>
		<td colspan="12"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td colspan="7" rowspan="2"></td>
		<td colspan="3" rowspan="3" align="left" valign="top">
			<div id="logo">
				<img id="logo-image" src="<?=$logo;?>" width="119" height="112" alt="">
			</div>
		</td>
		<td colspan="2" rowspan="6"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="33" alt=""></td>
	</tr>
	<tr>
		<td colspan="5"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="18" alt=""></td>
	</tr>
	<tr>
		<td colspan="11" rowspan="2" align="left" valign="top">
			<div id="card-owner-name">
				<h1><?= $name ; ?></h1>
			</div>
		</td>
		<td rowspan="4"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="61" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" rowspan="3"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="81" alt=""></td>
	</tr>
	<tr>
		<td colspan="11"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="32" alt=""></td>
	</tr>
	<tr>
		<td colspan="7" align="left" valign="top">
			<div class="testimony">
				<p id="testimoy"><?=$testimony?></p>
			</div>
		</td>
		<td colspan="4"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="23" alt=""></td>
	</tr>
	<tr>
		<td colspan="8"></td>
		<td rowspan="2" align="left" valign="top">
			<img src="template-images/card-01/images/CARD-DESIGN-I_16.jpg" width="49" height="46" alt="">
		</td>
		<td rowspan="2">
			<img src="template-images/card-01/images/CARD-DESIGN-I_17.jpg" width="3" height="46" alt=""></td>
		<td colspan="6" rowspan="2" align="left" valign="top">
			<p id="phone" style="margin-top: 20px"><?=$phone;?></p>
		</td>
		<td rowspan="8"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="33" alt=""></td>
	</tr>
	<tr>
		<td colspan="4" rowspan="3"></td>
		<td colspan="2" rowspan="4" align="left" valign="top">
			<img src="template-images/card-01/images/CARD-DESIGN-I_21.jpg" width="60" height="55" alt="">
		</td>
		<td colspan="2"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="13" alt=""></td>
	</tr>
	<tr>
		<td colspan="7" rowspan="3" align="left" valign="top">
			<p id="email" style="margin-top: 10px"><?=$email;?></p>
		</td>
		<td colspan="3" align="left" valign="top">
			<img src="template-images/card-01/images/CARD-DESIGN-I_24.jpg" width="60" height="3" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="3" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" rowspan="2"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="25" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4"></td>
		<td rowspan="3" align="left" valign="top">
			<img src="template-images/card-01/images/CARD-DESIGN-I_27.jpg" width="61" height="49" alt=""></td>
		<td colspan="2">
			<img src="template-images/card-01/images/CARD-DESIGN-I_28.jpg" width="63" height="6" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td rowspan="3">
			<img src="template-images/card-01/images/CARD-DESIGN-I_29.jpg" width="4" height="59" alt=""></td>
		<td colspan="11" align="left" valign="top">
			<p id="address" style="margin-top: 10px"><?=$address;?></p>
		</td>
		<td colspan="2" rowspan="3">
			<img src="template-images/card-01/images/CARD-DESIGN-I_31.jpg" width="12" height="59" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="33" alt=""></td>
	</tr>
	<tr>
		<td colspan="11" rowspan="2"></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="template-images/card-01/images/CARD-DESIGN-I_33.jpg" width="61" height="16" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="15" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="39" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="61" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="59" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="55" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="5" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="80" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="15" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="49" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="3" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="69" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="48" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="2" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="10" height="1" alt=""></td>
		<td>
			<img src="template-images/card-01/images/spacer.gif" width="21" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>