<html>
<head>
<title>CARD (SVG) IV</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (CARD (SVG) IV.svg - Slices: 03, 06, 10, 14, 19, 22, 27, 30, 33, 35) -->
<table style="color: white; background-image: url(template-images/card-04/images/CARD-IV-BG.jpg); background-position: center; background-size: cover; background-repeat: no-repeat;" id="Table_01" width="551" height="421" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="550" height="9" colspan="18">
			<img src="template-images/card-04/images/spacer.gif" width="550" height="9" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="9" alt=""></td>
	</tr>
	<tr>
		<td width="6" height="411" rowspan="19">
			<img src="template-images/card-04/images/spacer.gif" width="6" height="411" alt=""></td>
		<td colspan="3" rowspan="2" align="left" valign="top">
			<div style="font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="testimony"><?=$testimony?></span>
			</div>
		</td>
		<td width="283" height="24" colspan="14">
			<img src="template-images/card-04/images/spacer.gif" width="283" height="24" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="24" alt=""></td>
	</tr>
	<tr>
		<td width="12" height="50" colspan="4" rowspan="4">
			<img src="template-images/card-04/images/spacer.gif" width="12" height="50" alt=""></td>
		<td colspan="6" rowspan="3" align="left" valign="top">
			<div style="font-weight:600; margin-left: 20px; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="position"><?=$position?></span>
			</div>
		</td>
		<td width="26" height="50" colspan="4" rowspan="4">
			<img src="template-images/card-04/images/spacer.gif" width="26" height="50" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td width="261" height="7" colspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="261" height="7" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="7" alt=""></td>
	</tr>
	<tr>
		<td width="22" height="361" rowspan="16">
			<img src="template-images/card-04/images/spacer.gif" width="22" height="361" alt=""></td>
		<td rowspan="3" align="left" valign="top">
			<div class="logo">
				<img id="logo-image" src="<?=$logo?>" width="202" height="167" alt="">
			</div>
		</td>
		<td width="37" height="361" rowspan="16">
			<img src="template-images/card-04/images/spacer.gif" width="37" height="361" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
	<tr>
		<td width="245" height="8" colspan="6">
			<img src="template-images/card-04/images/spacer.gif" width="245" height="8" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td width="11" height="200" colspan="3" rowspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="11" height="200" alt=""></td>
		<td colspan="8" rowspan="2" align="left" valign="top">
			<div style="font-weight:600; font-size: 3rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="card-owner-name"><?=$name?></span>
			</div>
		</td>
		<td width="25" height="258" colspan="3" rowspan="8">
			<img src="template-images/card-04/images/spacer.gif" width="25" height="258" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="143" alt=""></td>
	</tr>
	<tr>
		<td width="202" height="194" rowspan="13">
			<img src="template-images/card-04/images/spacer.gif" width="202" height="194" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="21" alt=""></td>
	</tr>
	<tr>
		<td width="247" height="36" colspan="8">
			<img src="template-images/card-04/images/spacer.gif" width="247" height="36" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="36" alt=""></td>
	</tr>
	<tr>
		<td width="10" height="54" colspan="2" rowspan="4">
			<img src="template-images/card-04/images/spacer.gif" width="10" height="54" alt=""></td>
		<td colspan="3" rowspan="3" align="left" valign="top">
			<img src="template-images/card-04/images/CARD-IV_19.jpg" width="33" height="48" alt=""></td>
		<td width="215" height="13" colspan="6">
			<img src="template-images/card-04/images/spacer.gif" width="215" height="13" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="13" alt=""></td>
	</tr>
	<tr>
		<td width="1" height="41" rowspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="1" height="41" alt=""></td>
		<td colspan="3" align="left" valign="top">
			<div style="font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="phone"><?=$phone?></span>
			</div>
		</td>
		<td width="40" height="45" colspan="2" rowspan="4">
			<img src="template-images/card-04/images/spacer.gif" width="40" height="45" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="27" alt=""></td>
	</tr>
	<tr>
		<td width="174" height="14" colspan="3" rowspan="2">
			<img src="template-images/card-04/images/spacer.gif" width="174" height="14" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td width="33" height="6" colspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="33" height="6" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td width="9" height="83" rowspan="7">
			<img src="template-images/card-04/images/spacer.gif" width="9" height="83" alt=""></td>
		<td colspan="6" align="left" valign="top">
			<img src="template-images/card-04/images/CARD-IV_27.jpg" width="36" height="4" alt=""></td>
		<td width="173" height="4" colspan="2">
			<img src="template-images/card-04/images/spacer.gif" width="173" height="4" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td colspan="5" align="left" valign="top">
			<img src="template-images/card-04/images/CARD-IV_29.jpg" width="35" height="28" alt=""></td>
		<td colspan="6" align="left" valign="top">
			<div style="font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="email"><?=$email?></span>
			</div>
		</td>
		<td width="12" height="36" colspan="2" rowspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="12" height="36" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="28" alt=""></td>
	</tr>
	<tr>
		<td width="262" height="4" colspan="11">
			<img src="template-images/card-04/images/spacer.gif" width="262" height="4" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td colspan="7" rowspan="3" align="left" valign="top">
			<img src="template-images/card-04/images/CARD-IV_33.jpg" width="37" height="39" alt=""></td>
		<td width="225" height="4" colspan="4">
			<img src="template-images/card-04/images/spacer.gif" width="225" height="4" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td colspan="5" align="left" valign="top">
			<div style="font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="address"><?=$address?></span>
			</div>
		</td>
		<td width="9" height="43" rowspan="3">
			<img src="template-images/card-04/images/spacer.gif" width="9" height="43" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="31" alt=""></td>
	</tr>
	<tr>
		<td width="228" height="12" colspan="5" rowspan="2">
			<img src="template-images/card-04/images/spacer.gif" width="228" height="12" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td width="37" height="8" colspan="7">
			<img src="template-images/card-04/images/spacer.gif" width="37" height="8" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="6" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="22" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="202" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="37" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="9" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="31" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="172" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="39" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="13" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="3" height="1" alt=""></td>
		<td>
			<img src="template-images/card-04/images/spacer.gif" width="9" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>