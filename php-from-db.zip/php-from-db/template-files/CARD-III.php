<html>
<head>
<title>CARD III (SVG)</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (CARD III (SVG).svg - Slices: 03, 06, 11, 14, 18, 21, 24, 27, 29, 32) -->
<table style="background-image: url(template-images/card-03/images/CARD-III-BG.jpg); background-repeat: no-repeat; background-position: center; background-size: cover" id="Table_01" width="551" height="421" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="550" height="19" colspan="20">
			<img src="template-images/card-03/images/spacer.gif" width="550" height="19" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td width="283" height="6" colspan="11">
			<img src="template-images/card-03/images/spacer.gif" width="283" height="6" alt=""></td>
		<td colspan="7" rowspan="2" align="left" valign="top">
			<div style="font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif">
				<span id="testimony"><?=$testimony?></span>
			</div>
		</td>
		<td width="19" height="368" colspan="2" rowspan="10">
			<img src="template-images/card-03/images/spacer.gif" width="19" height="368" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td width="32" height="345" colspan="2" rowspan="7">
			<img src="template-images/card-03/images/spacer.gif" width="32" height="345" alt=""></td>
		<td colspan="6" rowspan="2" align="left" valign="top">
			<div class="logo">
				<img id="logo-image" src="<?=$logo?>" width="118" height="111" alt="">
			</div>
		</td>
		<td width="133" height="121" colspan="3" rowspan="3">
			<img src="template-images/card-03/images/spacer.gif" width="133" height="121" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="48" alt=""></td>
	</tr>
	<tr>
		<td width="248" height="73" colspan="7" rowspan="2">
			<img src="template-images/card-03/images/spacer.gif" width="248" height="73" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="63" alt=""></td>
	</tr>
	<tr>
		<td width="118" height="10" colspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="118" height="10" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td width="77" height="224" colspan="3" rowspan="4">
			<img src="template-images/card-03/images/spacer.gif" width="77" height="224" alt=""></td>
		<td colspan="12" align="left" valign="top">
			<div style="text-align: center; font-size: 3rem">
				<span id="card-owner-name"><?=$name?></span>
			</div>
		</td>
		<td width="44" height="241" rowspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="44" height="241" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="78" alt=""></td>
	</tr>
	<tr>
		<td width="98" height="152" colspan="5" rowspan="4">
			<img src="template-images/card-03/images/spacer.gif" width="98" height="152" alt=""></td>
		<td colspan="4" align="left" valign="top">
			<div style="text-align: center; font-size: 2rem">
				<span id="position"><?=$position?></span>
			</div>
		</td>
		<td width="138" height="144" colspan="3" rowspan="2">
			<img src="template-images/card-03/images/spacer.gif" width="138" height="144" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="28" alt=""></td>
	</tr>
	<tr>
		<td width="142" height="116" colspan="4">
			<img src="template-images/card-03/images/spacer.gif" width="142" height="116" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="116" alt=""></td>
	</tr>
	<tr>
		<td width="124" height="19" colspan="3" rowspan="3">
			<img src="template-images/card-03/images/spacer.gif" width="124" height="19" alt=""></td>
		<td colspan="3" rowspan="3" align="left" valign="top">
			<img src="template-images/card-03/images/CARD-III_18.jpg" width="40" height="19" alt=""></td>
		<td width="116" height="19" rowspan="3">
			<img src="template-images/card-03/images/spacer.gif" width="116" height="19" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td width="14" height="50" rowspan="8">
			<img src="template-images/card-03/images/spacer.gif" width="14" height="50" alt=""></td>
		<td colspan="2" rowspan="5" align="left" valign="top">
			<img src="template-images/card-03/images/CARD-III_21.jpg" width="24" height="42" alt=""></td>
		<td width="71" height="17" colspan="2" rowspan="2">
			<img src="template-images/card-03/images/spacer.gif" width="71" height="17" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td width="28" height="11" colspan="2">
			<img src="template-images/card-03/images/spacer.gif" width="28" height="11" alt=""></td>
		<td colspan="2" rowspan="5" align="left" valign="top">
			<img src="template-images/card-03/images/CARD-III_24.jpg" width="35" height="37" alt=""></td>
		<td width="35" height="11">
			<img src="template-images/card-03/images/spacer.gif" width="35" height="11" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="11" alt=""></td>
	</tr>
	<tr>
		<td width="1" height="33" rowspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="1" height="33" alt=""></td>
		<td colspan="2" align="left" valign="top">
			<div style="font-weight:600; margin-top: -5px; font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="phone"><?=$phone?></span>
			</div>
		</td>
		<td width="3" height="33" rowspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="3" height="33" alt=""></td>
		<td colspan="3" rowspan="3" align="left" valign="top">
			<div style="font-weight:600; margin-top: -5px; font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="email"><?=$email?></span>
			</div>
		</td>
		<td width="1" height="33" rowspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="1" height="33" alt=""></td>
		<td colspan="2" rowspan="2" align="left" valign="top">
			<img src="template-images/card-03/images/CARD-III_31.jpg" width="39" height="23" alt=""></td>
		<td colspan="4" rowspan="5" align="left" valign="top">
			<div style="font-weight:600; margin-top: -5px; font-size: .9rem; font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
				<span id="address"><?=$address?></span>
			</div>
		</td>
		<td width="8" height="33" rowspan="6">
			<img src="template-images/card-03/images/spacer.gif" width="8" height="33" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
	<tr>
		<td width="95" height="17" colspan="2" rowspan="5">
			<img src="template-images/card-03/images/spacer.gif" width="95" height="17" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="7" alt=""></td>
	</tr>
	<tr>
		<td width="39" height="10" colspan="2" rowspan="4">
			<img src="template-images/card-03/images/spacer.gif" width="39" height="10" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td width="24" height="8" colspan="2" rowspan="3">
			<img src="template-images/card-03/images/spacer.gif" width="24" height="8" alt=""></td>
		<td width="158" height="8" colspan="3" rowspan="3">
			<img src="template-images/card-03/images/spacer.gif" width="158" height="8" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="1" alt=""></td>
	</tr>
	<tr>
		<td width="35" height="7" colspan="2" rowspan="2">
			<img src="template-images/card-03/images/spacer.gif" width="35" height="7" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="3" alt=""></td>
	</tr>
	<tr>
		<td width="172" height="4" colspan="4">
			<img src="template-images/card-03/images/spacer.gif" width="172" height="4" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="18" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="6" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="70" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="25" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="3" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="13" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="22" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="35" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="76" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="47" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="18" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="21" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="116" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="44" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="template-images/card-03/images/spacer.gif" width="8" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>