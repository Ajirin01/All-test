<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LitCaf card maker</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <!-- CSS code for the modal dialog -->
<style>
    .modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    }

    .close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    }

    .close:hover,
    .close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
    }

    .thumbnail {
    width: 200px;
    height: 150px;
    object-fit: cover;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
  }
  
  .thumbnail:hover {
    transform: scale(2);
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  }
</style>
</head>
<body>
    

<?php
// Array of template filenames and their corresponding thumbnail filenames
$templates = array(
    'template1' => array(
        'template_file' => 'template-files/CARD-I.php',
        'template_snapshot' => 'template-snapshots/CARD-I.jpg'
    ),
    'template2' => array(
        'template_file' => 'template-files/CARD-II.php',
        'template_snapshot' => 'template-snapshots/CARD-II.jpg'
    ),
    'template3' => array(
        'template_file' => 'template-files/CARD-III.php',
        'template_snapshot' => 'template-snapshots/CARD-III.jpg'
    ),
    'template4' => array(
        'template_file' => 'template-files/CARD-IV.php',
        'template_snapshot' => 'template-snapshots/CARD-IV.jpg'
    ),
    'template5' => array(
        'template_file' => 'template-files/CARD-V.php',
        'template_snapshot' => 'template-snapshots/CARD-V.jpg'
    )
//   'template1' => 'template-snapshots/CARD-I.jpg',
//   'template2' => 'template-snapshots/CARD-II.jpg',
//   'template3' => 'template-snapshots/CARD-III.jpg',
//   'template4' => 'template-snapshots/CARD-IV.jpg',
//   'template5' => 'template-snapshots/CARD-V.jpg',
);
?>

<!-- Button to open the modal dialog -->


<!-- The modal dialog -->
<div id="myModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <div class="thumbnail-grid">
      <?php
      // Generate the HTML code for the thumbnail grid
      foreach ($templates as $template => $thumbnail) {
        echo '<img class="thumbnail" src="' . $thumbnail['template_snapshot'] . '" alt="' . $template . '" onclick="selectTemplate(\'' . $thumbnail['template_file'] . '\', \'' . $template . '\')">'; 

      }
      ?>
    </div>
  </div>
</div>
<div class="container">
    <div class="row">
        <div class="card hoverable">
            <div class="center-align">
                <img src="https://litcaf.com/wp-content/uploads/2016/03/LOGO-G.png" alt="">
            </div>
            <div class="row">
                <form action="submit.php" method="post" class="card-content col s12">
                    <div class="row">
                        <div class="input-field col s12 m6">
                        <input placeholder="e.g. Olagoke Mubark" name="name" id="name" type="text" class="validate">
                        <label for="name">Full Name</label>
                        </div>
                        <div class="input-field col s12 m6">
                        <input placeholder="e.g. mubarakolagoke@gmail.com" name="email" id="email" type="email" class="validate">
                        <label for="first_name">Email</label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input placeholder="e.g. Ajah, Lagos, Nigeria" name="address" id="address" type="text" class="validate">
                            <label for="address">Address</label>
                        </div>
                        <div class="input-field col s12 m6">
                            <input placeholder="e.g. 08034834798" name="phone" id="phone" type="tel" class="validate">
                            <label for="phone">Phone number</label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input placeholder="e.g. Tailor" name="position" id="position" type="text" class="validate">
                            <label for="position">Occupation</label>
                        </div>
                        <div class="input-field col s12 m6">
                            <div class="btn">
                                <span>Logo</span>
                                <input type="file" name="logo" id="fileInput" onchange="previewImage()">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="input-field col s12 m6">
                            <p class="btn waves-effect waves-light" onclick="openModal()">Select Template</p> <span style="color: green" id="report">No template selected!</span>
                        </div>
                        <div class="input-field col s12 m6">
                            <img id="imagePreview" style="max-width: 150px; max-height: 150px" />
                        </div>
                    </div>

                    <button class="btn waves-effect waves-light" type="submit" name="submit">Submit</button>
            

                    <!-- The select element to store the selected template -->
                    <select style="display: none" id="image-select" name="template">
                    <option value="" selected disabled>Select a template</option>
                    <?php
                    foreach ($templates as $template => $thumbnail) {
                        echo '<option value="' . $thumbnail['template_file'] . '">' . $template . '</option>';
                    }
                    ?>
                    </select>

                    <input type="hidden" name="logo-image" id="logo">

                    <!-- <input type="submit" value="Submit"> -->
                </form>
            </div>
        </div>
    </div>
</div> 
<!-- JavaScript code to handle the modal dialog and thumbnail selection -->
<script>
var modal = document.getElementById("myModal");
var last_event;

function openModal() {
  modal.style.display = "block";
}

function closeModal() {
  modal.style.display = "none";
}

function selectTemplate(thumbnail, template) {
  // Set the value of the select element to the filename of the selected thumbnail
  document.getElementById('image-select').value = thumbnail;
  document.getElementById('report').innerText = template + " already selected!";

  // Highlight the selected thumbnail
  if (last_event != undefined) {
    last_event.style.opacity = "1";
  }
  event.target.style.opacity = "0.4";
  last_event = event.target;

  // Close the modal dialog
  closeModal();
}

// Close the modal dialog when the user clicks outside of it
window.onclick = function(event) {
  if (event.target == modal) {
    closeModal();
  }
}

function previewImage() {
  var fileInput = document.getElementById('fileInput');
  var file = fileInput.files[0];

  // Create a new FileReader object
  var reader = new FileReader();

  // Set the onload event handler to display the image
  reader.onload = function() {
    var imagePreview = document.getElementById('imagePreview');
    document.getElementById('logo').value = reader.result
    imagePreview.src = reader.result;
  };

  // Read the file data as a URL
  reader.readAsDataURL(file);
}

</script>



</body>
</html>
