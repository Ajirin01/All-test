<?php
    if(isset($_POST['template'])){
        $name = $_POST['name'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $position = $_POST['position'];
        $email = $_POST['email'];
        $logo = $_POST['logo-image'];
        $testimony = "No testimonials at the moment, will be updated when available";
        include_once($_POST['template']);
    }
    

?>